// Layer: Interface — generic condition and target contracts used across the move system.
// ICondition<T>: checks a boolean condition against an entity of type T.
// ITarget: resolves to a PokemonDomain given the current battle state.

using PokemonGame.Model.Model.Helper.BattleHelper;
using PokemonGame.Model.Model.Helper.PokemonHelper;

namespace PokemonGame.Model.Interface
{
    // Generic condition — can check against BattleDomain or PokemonDomain
    internal interface ICondition<T>
    {
        bool Check(T entity);
    }

    // Resolves which Pokemon is the target for an effect or condition
    internal interface ITarget
    {
        PokemonState Resolve(BattleState battle);
    }
}

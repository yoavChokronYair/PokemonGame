﻿using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using PokemonGame.Services.Handler;
using PokemonGame.ViewModels.Store;
using PokemonGame.ViewModels.ViewModelHelper;


namespace PokemonGame.ViewModels.ViewModelPage.SignUp
{
    public class SignUpViewModel : ViewModelBase
    {
        private readonly NavigationStore _navigationStore;
        private readonly UserStore _userStore;
        public ViewModelBase CurrentViewModel => _navigationStore.CurrentViewModel;

        private readonly SignUpService _signUpHandler;

        private string _userName = string.Empty;
        private string _password = string.Empty;
        private string _confirmPassword = string.Empty;
        private string _statusMessage = string.Empty;

        public SignUpViewModel(UserStore userStore, NavigationStore navigationStore, Func<LogInViewModel> createLogInViewModel, Func<GameModeChooserViewModel> createGameChooserViewModel)
        {
            _userStore = userStore;
            _navigationStore = navigationStore;
            _signUpHandler = new SignUpService();

            SignUpCommand = new RelayCommand(SignUp);
            SwitchToLogInCommand = new NavigateCommand(navigationStore, createLogInViewModel);
            NavigateToGameModeChooserCommand =
            new NavigateCommand(navigationStore, createGameChooserViewModel);
        }

        // ------------------ PROPERTIES ------------------

        public string UserName
        {
            get => _userName;
            set
            {
                _userName = value;
                OnPropertyChanged(nameof(UserName));
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                OnPropertyChanged(nameof(Password));
            }
        }

        public string ConfirmPassword
        {
            get => _confirmPassword;
            set
            {
                _confirmPassword = value;
                OnPropertyChanged(nameof(ConfirmPassword));
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set
            {
                _statusMessage = value;
                OnPropertyChanged(nameof(StatusMessage));
            }
        }

        // ------------------ COMMANDS ------------------

        public ICommand SignUpCommand { get; }
        public ICommand SwitchToLogInCommand { get; }
        public ICommand NavigateToGameModeChooserCommand { get; }


        private void SignUp()
        {
            StatusMessage = "";

            if (string.IsNullOrWhiteSpace(UserName) ||
                string.IsNullOrWhiteSpace(Password) ||
                string.IsNullOrWhiteSpace(ConfirmPassword))
            {
                StatusMessage = "All fields are required";
                return;
            }

            if (Password != ConfirmPassword)
            {
                StatusMessage = "Passwords do not match";
                return;
            }

            if (Password.Length < 6)
            {
                StatusMessage = "Password must be at least 6 characters";
                return;
            }

            var success = _signUpHandler.CreateUser(UserName, Password);

            if (!success)
            {
                StatusMessage = "Username already exists";
                return;
            }

            _userStore.Username = UserName;
            NavigateToGameModeChooserCommand.Execute(null);
        }

    }
}

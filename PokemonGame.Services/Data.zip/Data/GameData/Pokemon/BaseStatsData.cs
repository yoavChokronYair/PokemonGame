﻿using PokemonGame.Services.Data.GameData;
using System;
using System.Collections.Generic;
using System.Text;

namespace PokemonGame.Services.Data.GameData.Pokemon
{
    public sealed class BaseStatsData
    {
        public int PokemonID{ get; set; }
        public byte HP { get; set; }
        public byte Attack { get; set; }
        public byte Defence { get; set; }
        public byte SpAttack { get; set; }
        public byte SpDefence { get; set; }
        public byte Speed { get; set; }
        public int Type1 { get; set; }//should be enum in model
        public int Type2 { get; set; }//should be enum in model
        public byte CathRate { get; set; }
        public byte EggCycles { get; set; }
        public byte BaseFriendship { get; set; }
        public int GenderRatio { get; set; }//should be enum in model
        public int GrowthRate { get; set; }//should be enum in model
        public ushort BaseExpYield { get; set; }
        public int EggGroup1 { get; set; }//should be enum in model
        public int EggGroup2 { get; set; }//should be enum in model
        public AbilityData? Ability1 { get; set; }
        public AbilityData? Ability2 { get; set; }
        public AbilityData? AbilityH { get; set; }
        public byte FleeRate { get; set; }
        public float Weight { get; set; }

       
    }
}
﻿
namespace PokemonGame.Services.Data.GameData.Pokemon
{
    public sealed class LevelUpMoveData
    {
        public int MoveName { get; set; }//should be enum in model 
        public byte Level {  get; set; }
        public int PokemonID { get; set; }
    }
}

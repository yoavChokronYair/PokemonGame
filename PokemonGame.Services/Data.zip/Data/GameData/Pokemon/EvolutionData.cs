﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PokemonGame.Services.Data.GameData.Pokemon
{
    public sealed class EvolutionData
    {
        
        public int PokemonID { get; set; }
        public ushort LevelRequired { get; set; }
        public string BabySpeciesName { get; set; }
        public int Method { get; set; }//should be enum in model
        public string SpeciesName { get; set; }
        public PokemonFormData Form { get; set; }
    }
}

﻿
namespace PokemonGame.Services.Data.GameData.MapData
{
    public class RouteMapData : WorldData
    {
        public int ID { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public List<WorldRegion>? Regions { get; set; }
        public List<Encounter>? Encounters { get; set; }
        public int[]? TownConnections { get; set; }//first value:first town,second value:second town 
        public int pathID { get; set; }
    }
    public class RouteMapDataList
    {
        public List<RouteMapData>? maps;
    }
    public class Encounter
    {
        public string? Name { get; set; }
        public int MinLevel { get; set; }
        public int MaxLevel { get; set; }
        public double Rarity {  get; set; }
        public string? Environment { get; set; }
    }
    
}
